
#include <stdio.h>
float circleDiameter(float radius){
    
    return 2 * radius;
     
}

float circleCircumference(float radius){
    const float PI = 3.14;
    
    return 2 * PI * radius;
}

float circleArea(float radius){
    const float PI = 3.14;
    
    
    return PI * radius * radius;
}
int main(){
    
    
    float radius, diameter, circumference, area;
    
    printf("Enter the Radius of the Circle: ");
    scanf("%f", &radius);
    
    diameter = circleDiameter(radius);  
    circumference = circleCircumference(radius);
    area = circleArea(radius);
    
    printf("The diameter of the circle is: %f", diameter);
    printf("\nThe circumference of the circle is: %f", circumference);
    printf("\nThe Area of the Circle is: %f", area);
    
    return 0;
    
}