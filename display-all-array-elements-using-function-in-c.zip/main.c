#include <stdio.h>
#define ROWS 3
#define COLS 3
void inputMatrix(int (*mat)[COLS]);
void printMatrix(int mat[][COLS]);
int main()
{
    int mat[ROWS][COLS];
    inputMatrix(mat);
    printMatrix(mat);    
    return 0;
}
void inputMatrix(int (*mat)[COLS])
{
    int i, j;
    printf("Enter elements in 2D matrix: \n");
    for (i = 0; i < ROWS; i++)
    {
        for (j = 0; j < COLS; j++)
        {
            scanf("%d", (*(mat + i) + j));
        }
    }
}
void printMatrix(int (*mat)[COLS])
{
    int i, j;
    printf("Elements in matrix: \n");
    for (i = 0; i < ROWS; i++)
    {
        for (j = 0; j < COLS; j++)
        {
            printf("%d ", *(*(mat + i) + j));
        }
        printf("\n");
    }
}