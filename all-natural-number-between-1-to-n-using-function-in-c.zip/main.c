
#include <stdio.h>
void nat(int);
int main()
{
    int i, n;
    printf("Enter any number: ");
    scanf("%d", &n);
     nat(n);
    return 0;
}
void nat(int n)
{
    printf("Natural numbers from 1 to %d : \n", n);
    for(int i=1; i<=n; i++)
    {
        printf("%d\n", i);
    }

}