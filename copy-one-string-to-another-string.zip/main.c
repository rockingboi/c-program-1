#include <stdio.h>
#include <string.h>

int main() {
   char source[] = "Hello, world!"; 
   char destination[20]; 
   strcpy(destination, source);

   printf("main string: %s\n", source);
   printf("copied string: %s\n", destination);
   return 0;
}
