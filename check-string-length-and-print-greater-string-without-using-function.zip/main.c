#include <stdio.h>

int main() {
    char str1[100],str2[100];

    int len1 = 0, len2 = 0;
    int i = 0;
    scanf("%s",str1);
    scanf("%s",str2);

    while (str1[i] != '\0') {
        len1++;
        i++;
    }

    i = 0;

    while (str2[i] != '\0') {
        len2++;
        i++;
    }

    if (len1 > len2) {
        printf("Length of str1 is greater: %d\n", len1);
    } else {
        printf("Length of str2 is greater: %d\n", len2);
    }

    return 0;
}
