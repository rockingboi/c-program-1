#include <stdio.h>

int findMax(int arr[], int start, int end)
{
    if (start == end) 
    {
        return arr[start]; 
    }
    else
    {
        int mid = (start + end) / 2;
        int leftMax = findMax(arr, start, mid); 
        int rightMax = findMax(arr, mid + 1, end);  
        
        if (leftMax > rightMax)
            return leftMax;
        else
            return rightMax;
    }
}

int findMin(int arr[], int start, int end) {
    if (start == end)
    {
        return arr[start]; 
    } 
    else
    {
        int mid = (start + end) / 2;
        int leftMin = findMin(arr, start, mid);  
        int rightMin = findMin(arr, mid + 1, end);  
        
        if (leftMin < rightMin)
            return leftMin;
        else
            return rightMin;
    }
}

int main() 
{
    int arr[] = {5, 2, 9, 1, 7};
    int n = sizeof(arr) / sizeof(arr[0]);

    int max = findMax(arr, 0, n - 1);
    int min = findMin(arr, 0, n - 1);
    
    printf("Maximum element: %d\n", max);
    printf("Minimum element: %d\n", min);
    
    return 0;
}
