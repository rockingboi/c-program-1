#include <stdio.h>
#include <string.h>

int main() {
    char str1[100], str2[100];
    int len1, len2;

    printf("Enter string 1: ");
    scanf("%s", str1);

    printf("Enter string 2: ");
    scanf("%s", str2);

    len1 = strlen(str1);
    len2 = strlen(str2);

    if (len1 > len2) {
        printf("String 1 is longer (%d characters)\n", len1);
    } else if (len2 > len1) {
        printf("String 2 is longer (%d characters)\n", len2);
    } else {
        printf("The strings are of equal length (%d characters)\n", len1);
    }

    return 0;
}
