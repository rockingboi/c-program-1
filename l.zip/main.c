#include <stdio.h>
#include <string.h>

void main()
{
    char a[100];
    int len;
    scanf("%s",a);
    len=strlen(a);
    printf("%d",len);
}
